package sample.utils;

import javafx.scene.control.Button;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CalendarUtils {
    public int getTodayYear() {
        Date date = new Date();
        DateFormat format = new SimpleDateFormat("yyyy");
        String year = format.format(date);
        return Integer.parseInt(year);
    }
    public int getTodayMonth() {
        Date date = new Date();
        DateFormat format = new SimpleDateFormat("MM");
        String month = format.format(date);
        return Integer.parseInt(month);
    }

    public void getTimeNumber(int row, int col, int month, int year) throws ParseException {
        SimpleDateFormat dc = new SimpleDateFormat();
        dc.applyPattern("yyyy-MM-dd");
        String dateString = String.valueOf(year)+"-"+String.valueOf(month)+"-01";
        Date date = dc.parse(dateString);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        System.out.println(calendar.get(Calendar.DAY_OF_WEEK));
        calendar.add(Calendar.MONTH, -1);
        System.out.println(calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
    }
}
