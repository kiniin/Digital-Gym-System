package sample.controller;

import sample.pojo.User;


public interface ReadTextFieldable {
    public User readTextField();
}
